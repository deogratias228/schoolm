/*
 * Bean Validation API
 *
 * License: Apache License, Version 2.0
 * See the license.txt file in the root directory or <http://www.apache.org/licenses/LICENSE-2.0>.
 */
/**
 * Package containing all objects specifically used and returned by the
 * metadata API.
 */
package javax.validation.metadata;
